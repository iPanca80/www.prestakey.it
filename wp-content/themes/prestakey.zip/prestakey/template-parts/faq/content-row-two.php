
<!-- Row 02 - start -->
<section class="row-two row-custom bg-color">
    <div class="container">
    <div class="col-12 d-flex justify-content-end">
                <h1 class="col-8 mb-5 mt-5">Le domande piu frequenti riguardo <strong>PrestaKey</strong>.</h1>
            </div>
        <div class="col-12 d-flex justify-content-end">
            <div class="col-8"><?php get_template_part( '/template-parts/faq' ); ?></div>
        </div>
    </div>
</section>
<!-- Row 02 - end -->