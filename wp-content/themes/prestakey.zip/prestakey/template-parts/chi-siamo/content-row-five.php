
<!-- Row 05 - start -->
<style>
    .page-id-46 section.row-five .container {
    background: url(<?php echo get_template_directory_uri(); ?>/svg/illustrazione-chi-siamo-row-three.svg);
    background-repeat: no-repeat;
    background-position: right 165px;
    background-size: 25%;
}
</style>
<section class="row-five row-custom">
    <div class="container">
        <div>
            <div class="col-12">
                <h1 class="col-8 mb-5 mt-5">Il team partner di <strong>PrestaKey</strong>.</h1>
            </div>
            <div class="col-8">
                <h4 class="mb-5 mt-5">
                </h4>
            </div>
        </div>
    </div>
</section>
<!-- Row 05 - end -->