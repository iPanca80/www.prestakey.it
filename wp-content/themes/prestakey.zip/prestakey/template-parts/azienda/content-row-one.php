<!-- Row slider - start -->
<section class="row-one row-custom">
    <div class="col-12">
        <div class="slider">
            <div class="col-7">
                <h1 class="mb-5 mt-5 text-white"><strong>Sei un’azienda</strong> alla ricerca di un <strong>finanziamento</strong> per migliorare il tuo <strong>business?</strong>.</h1>
            </div>
            <div class="col-7">
                <h4 class="mb-5 mt-5 text-white">
                Con <strong>PrestaKey</strong> puoi ottenere <strong>fino a 150.000 € nella maniera più rapida possibile</strong>: in pochi click, senza burocrazia e procedure complicate. Sia per ditte individuali che per aziende.
                </h4>
            </div>
        </div>
</section>
<!-- Row slider - end -->