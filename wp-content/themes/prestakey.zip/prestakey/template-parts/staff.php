<!-- Features - start -->
<div class="container features pt-5 pb-5" style="background:none;">

    <div class="row align-items-start">

        <div class="feature one col-12 col-xs-12 col-sm-12 col-lg-4">
            <div class="feature-container">
                <div class="feature-icon">
                    
                </div>
                <h2 class="fw-bold lh-base fs-4">Roberto Ghilardini</h2>
                <p class="lh-base">Executive Chairman</p>
            </div>
        </div>

        <div class="feature two col-12 col-xs-12 col-sm-12 col-lg-4 mt-5 mt-lg-0">
            <div class="feature-container">
                <div class="feature-icon">
                   
                </div>
                <h2 class="fw-bold lh-base fs-4">Guido Lami Montapert</h2>
                <p class="lh-base">Chief Executive Officer</p>
            </div>
        </div>

        <div class="feature three col-12 col-xs-12 col-sm-12 col-lg-4 mt-5 mt-lg-0">
            <div class="feature-container">
                <div class="feature-icon">
                   
                </div>
                <h2 class="fw-bold lh-base fs-4">Federico Teruzzi</h2>
                <p class="lh-base">Credit Analyst Manager</p>
            </div>
        </div>

    </div>

    <div class="row align-items-start pt-5">

        <div class="feature four col-12 col-xs-12 col-sm-12 col-lg-4">
            <div class="feature-container">
                <div class="feature-icon">
                    
                </div>
                <h2 class="fw-bold lh-base fs-4">Matteo Pancani</h2>
                <p class="lh-base">IT Manager</p>
            </div>
        </div>

        <div class="feature five col-12 col-xs-12 col-sm-12 col-lg-4 mt-5 mt-lg-0">
            <div class="feature-container">
                <div class="feature-icon">
                
                </div>
                <h2 class="fw-bold lh-base fs-4">Fabio Stefani</h2>
                <p class="lh-base">Back Office Manager</p>
            </div>
        </div>

        <div class="feature six col-12 col-xs-12 col-sm-12 col-lg-4 mt-5 mt-lg-0">
            <div class="feature-container">
                <div class="feature-icon">
                    
                </div>
                <h2 class="fw-bold lh-base fs-4">Fabio Psoroulas</h2>
                <p class="lh-base">Communication Manager</p>
            </div>
        </div>

    </div>

</div>
<!-- Features - end -->