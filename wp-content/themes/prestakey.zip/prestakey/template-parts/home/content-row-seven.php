
<!-- Row 07 - start -->
<section class="row-seven row-custom">
    <div class="container">
        <div>
            <div class="col-12">
                <h1 class="col-8 mb-5 mt-5"><strong>PrestaKey</strong>: Dicono di noi.</h1>
            </div>
            <div class="col-12">
                <div class="col-8">
                    <h6 class="mb-5 mt-5">
                        <p>Scopri tutte le altre recensioni su <strong>PrestaKey</strong>.</p>
                    </h6>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Row 07 - end -->