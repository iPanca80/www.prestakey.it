<!-- Row slider - start -->
<section class="row-one row-custom">
    <div class="col-12">
        <div class="slider">
            <div class="col-8">
                <h1 class="mb-5 mt-5 text-white">Hai bisogno di supporto? <strong>PrestaKey</strong> è a tua completa disposzione.</h1>
            </div>
            <div class="col-7">
                <h4 class="mb-5 mt-5 text-white">
                La piattaforma ti aiuta in <strong>ogni fase della tua richiesta di finanziamento</strong>. Se hai bisogno di assistenza non esitare a contattare il Servizio Clienti tramite mail, telefono o form dei contatti.
                </h4>
            </div>
        </div>
</section>
<!-- Row slider - end -->